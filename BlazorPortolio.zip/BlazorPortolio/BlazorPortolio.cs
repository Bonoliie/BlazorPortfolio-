using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using PortfolioBlazor;

var builder = WebAssemblyHostBuilder.CreateDefault(args);
try
{
    builder.RootComponents.Add<App>("#app");
    builder.RootComponents.Add<HeadOutlet>("head::after");
}
catch (Exception ex)
{
    Console.Error.WriteLine($"Error loading root components: {ex.Message}");
}

try
{
    await builder.Build().RunAsync();
}
catch (Exception ex)
{
    Console.Error.WriteLine($"Application failed to start: {ex.Message}");
}

// Adding necessary services for portfolio features
builder.Services.AddSingleton<PortfolioService>();
